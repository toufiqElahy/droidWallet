package com.wallet.crypto.trustapp.ui.widget;

public interface OnImportPrivateKeyListener {

    void onPrivateKey(String key);
}
