package com.wallet.crypto.trustapp.ui.widget;

public interface OnImportKeystoreListener {
    void onKeystore(String keystore, String password);
}
