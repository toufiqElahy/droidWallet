package com.wallet.crypto.trustapp.viewmodel;

public class CreateAccountViewModel extends BaseViewModel {

	public CreateAccountViewModel() {

	}
}
