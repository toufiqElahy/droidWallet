package com.wallet.crypto.trustapp.ui.widget;

import android.view.View;

import com.wallet.crypto.trustapp.entity.Token;

public interface OnTokenClickListener {
    void onTokenClick(View view, Token token);
}
