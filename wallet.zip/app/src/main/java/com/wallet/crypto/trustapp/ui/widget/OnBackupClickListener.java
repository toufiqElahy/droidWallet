package com.wallet.crypto.trustapp.ui.widget;

import android.view.View;

import com.wallet.crypto.trustapp.entity.Wallet;

public interface OnBackupClickListener {
    void onBackupClick(View view, Wallet wallet);
}
