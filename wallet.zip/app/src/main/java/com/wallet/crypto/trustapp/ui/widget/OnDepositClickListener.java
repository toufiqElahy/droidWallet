package com.wallet.crypto.trustapp.ui.widget;

import android.net.Uri;
import android.view.View;

public interface OnDepositClickListener {

    void onDepositClick(View view, Uri uri);
}
